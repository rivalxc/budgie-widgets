#!/bin/bash

aptitude search budgie-welcome &> /dev/null

if test $? -gt 0
    desktop_env='Unknown'
then
    desktop_env='Budgie'
fi

echo $desktop_env