#!/bin/bash

KELVIN=$(cut -d. -f1 <<< $1)
BASE=273
RESULT=$(($KELVIN - $BASE))
echo $RESULT