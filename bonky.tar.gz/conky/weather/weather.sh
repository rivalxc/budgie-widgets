#!/bin/bash

API_KEY=ec977d4541984b5ff3359a0a5dd9387c
LOCATION_ID=7532212
CURL_URL="api.openweathermap.org/data/2.5/weather?id=${LOCATION_ID}&appid=${API_KEY}"

curl ${CURL_URL} -s -o $HOME/.conky/weather/out.json