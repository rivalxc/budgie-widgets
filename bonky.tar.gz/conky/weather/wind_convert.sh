#!/bin/bash

KNOTS=$1
BASE=1.852
RESULT=$(echo $KNOTS*$BASE | bc)
echo $RESULT