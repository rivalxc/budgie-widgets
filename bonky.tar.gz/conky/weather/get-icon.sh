#!/usr/bin/env fish

set weather_code $argv[1]
cp -r $HOME/.conky/weather/weather-icons/$weather_code.png $HOME/.conky/weather/icon.png
